import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  fid: integer("fid").notNull().unique(),
  username: text("username").notNull(),
  avatarUrl: text("avatar_url"),
  points: integer("points").notNull().default(0),
  isPremium: boolean("is_premium").notNull().default(false),
  dailySpinsRemaining: integer("daily_spins_remaining").notNull().default(0),
  lastGmPayment: timestamp("last_gm_payment"),
  premiumPurchasedAt: timestamp("premium_purchased_at"),
});

export const spins = pgTable("spins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  pointsWon: integer("points_won").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // 'gm_fee' or 'premium'
  amount: text("amount").notNull(), // ETH amount as string
  txHash: text("tx_hash").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const rewards = pgTable("rewards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  pointsCost: integer("points_cost").notNull(),
  icon: text("icon").notNull(),
});

export const redemptions = pgTable("redemptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  rewardId: varchar("reward_id").notNull().references(() => rewards.id),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  fid: true,
  username: true,
  avatarUrl: true,
});

export const insertSpinSchema = createInsertSchema(spins).pick({
  userId: true,
  pointsWon: true,
});

export const insertPaymentSchema = createInsertSchema(payments).pick({
  userId: true,
  type: true,
  amount: true,
  txHash: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSpin = z.infer<typeof insertSpinSchema>;
export type Spin = typeof spins.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

export interface LeaderboardEntry {
  rank: number;
  user: User;
}

export interface SpinResult {
  pointsWon: number;
  newTotalPoints: number;
  spinsRemaining: number;
}

export type Reward = typeof rewards.$inferSelect;
export type Redemption = typeof redemptions.$inferSelect;
