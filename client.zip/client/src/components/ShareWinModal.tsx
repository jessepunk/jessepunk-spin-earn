import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Share2, X } from "lucide-react";
import { useFarcaster } from "./FarcasterProvider";
import sdk from "@farcaster/frame-sdk";

interface ShareWinModalProps {
  isOpen: boolean;
  onClose: () => void;
  pointsWon: number;
  totalPoints: number;
  username?: string;
}

export function ShareWinModal({
  isOpen,
  onClose,
  pointsWon,
  totalPoints,
  username = "User",
}: ShareWinModalProps) {
  const { user } = useFarcaster();
  const [isSharing, setIsSharing] = useState(false);

  const handleShare = async () => {
    setIsSharing(true);
    try {
      const message = `🎡 Just spun the Jessepunk Spin wheel and won ${pointsWon} points! 🎉\n\nTotal points: ${totalPoints}\n\nCan you beat my score? Play now!`;
      
      // Open Farcaster share/cast composer
      await sdk.actions.openUrl(
        `https://warpcast.com/~/compose?text=${encodeURIComponent(message)}`
      );
      
      setTimeout(() => {
        onClose();
        setIsSharing(false);
      }, 500);
    } catch (error) {
      console.error("Error sharing:", error);
      setIsSharing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Spin Win! 🎉</DialogTitle>
          <DialogDescription>Share your victory on Farcaster</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-primary/10 rounded-xl p-4 text-center">
            <div className="text-5xl font-bold text-primary mb-2">{pointsWon}</div>
            <p className="text-muted-foreground">Points Won!</p>
          </div>

          <div className="bg-secondary/10 rounded-xl p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">Total Score</p>
            <p className="text-3xl font-bold">{totalPoints}</p>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleShare}
              disabled={isSharing}
              className="flex-1 rounded-full"
              data-testid="button-share-to-farcaster"
            >
              <Share2 className="w-4 h-4 mr-2" />
              {isSharing ? "Sharing..." : "Share"}
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 rounded-full"
              data-testid="button-close-share-modal"
            >
              <X className="w-4 h-4 mr-2" />
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
