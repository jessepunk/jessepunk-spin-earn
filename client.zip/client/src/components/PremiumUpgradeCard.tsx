import { useState } from "react";
import { Zap, Check, Wallet } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { useAccount, useConnect, useSendTransaction, useWaitForTransactionReceipt } from "wagmi";
import { parseEther } from "viem";
import { injected } from "wagmi/connectors";

interface PremiumUpgradeCardProps {
  onPurchaseComplete: (txHash: string) => void;
}

const PREMIUM_PRICE_ETH = "0.0005";
const PAYMENT_ADDRESS = "0x0000000000000000000000000000000000000000";

export function PremiumUpgradeCard({ onPurchaseComplete }: PremiumUpgradeCardProps) {
  const [isPurchasing, setIsPurchasing] = useState(false);
  const { address, isConnected } = useAccount();
  const { connect } = useConnect();
  const { sendTransaction, data: txHash } = useSendTransaction();
  const { isSuccess } = useWaitForTransactionReceipt({
    hash: txHash,
  });

  const handleConnect = () => {
    connect({ connector: injected() });
  };

  const handlePurchase = async () => {
    if (!isConnected || !address) {
      handleConnect();
      return;
    }

    setIsPurchasing(true);
    try {
      await new Promise((resolve, reject) => {
        sendTransaction(
          {
            to: PAYMENT_ADDRESS,
            value: parseEther(PREMIUM_PRICE_ETH),
          },
          {
            onSuccess: resolve,
            onError: reject,
          }
        );
      });
    } catch (error) {
      console.error("Purchase failed:", error);
      setIsPurchasing(false);
    }
  };

  if (isSuccess && txHash) {
    onPurchaseComplete(txHash);
    setIsPurchasing(false);
  }

  const features = [
    "Unlimited daily spins",
    "Priority on leaderboard",
    "Exclusive premium badge",
    "Higher point multipliers",
  ];

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      data-testid="card-premium-upgrade"
    >
      <Card className="border-2 border-primary/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-chart-2/10 pointer-events-none" />
        
        <CardHeader className="relative">
          <div className="flex items-center justify-between">
            <Badge variant="default" className="animate-pulse-glow">
              <Zap className="w-3 h-3 mr-1" />
              LIMITED OFFER
            </Badge>
          </div>
          <CardTitle className="text-3xl font-heading mt-4">
            Go Premium
          </CardTitle>
          <CardDescription className="text-base">
            Unlock unlimited spins and boost your earnings
          </CardDescription>
        </CardHeader>

        <CardContent className="relative space-y-6">
          <div className="bg-card border border-card-border rounded-2xl p-6 text-center">
            <p className="text-sm text-muted-foreground mb-2">One-time payment</p>
            <p className="text-5xl font-bold font-heading text-primary" data-testid="text-premium-price">
              {PREMIUM_PRICE_ETH} ETH
            </p>
            <Badge variant="secondary" className="mt-3">
              <span className="text-xs">On Base Network</span>
            </Badge>
          </div>

          <div className="space-y-3">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-3"
              >
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Check className="w-4 h-4 text-primary" />
                </div>
                <span className="text-sm font-medium">{feature}</span>
              </motion.div>
            ))}
          </div>

          {!isConnected ? (
            <Button
              size="lg"
              className="w-full rounded-full text-lg font-bold py-6"
              onClick={handleConnect}
              data-testid="button-connect-wallet-premium"
            >
              <Wallet className="w-5 h-5 mr-2" />
              Connect Wallet
            </Button>
          ) : (
            <Button
              size="lg"
              className="w-full rounded-full text-lg font-bold py-6"
              onClick={handlePurchase}
              disabled={isPurchasing}
              data-testid="button-buy-premium"
            >
              {isPurchasing ? "Processing..." : "Upgrade to Premium"}
            </Button>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
