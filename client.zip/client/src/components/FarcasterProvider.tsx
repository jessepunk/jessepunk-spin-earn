import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import sdk from "@farcaster/frame-sdk";

interface FarcasterContextType {
  context: any | null;
  isReady: boolean;
  user: {
    fid: number;
    username: string;
    displayName: string;
    pfpUrl: string;
  } | null;
}

const FarcasterContext = createContext<FarcasterContextType>({
  context: null,
  isReady: false,
  user: null,
});

export function FarcasterProvider({ children }: { children: ReactNode }) {
  const [context, setContext] = useState<any | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const load = async () => {
      const ctx = await sdk.context;
      setContext(ctx);
      sdk.actions.ready();
      setIsReady(true);
    };
    load();
  }, []);

  const user = context?.user
    ? {
        fid: context.user.fid,
        username: context.user.username || `user${context.user.fid}`,
        displayName: context.user.displayName || context.user.username || `User ${context.user.fid}`,
        pfpUrl: context.user.pfpUrl || "",
      }
    : null;

  return (
    <FarcasterContext.Provider value={{ context, isReady, user }}>
      {children}
    </FarcasterContext.Provider>
  );
}

export function useFarcaster() {
  const context = useContext(FarcasterContext);
  if (!context) {
    throw new Error("useFarcaster must be used within FarcasterProvider");
  }
  return context;
}
