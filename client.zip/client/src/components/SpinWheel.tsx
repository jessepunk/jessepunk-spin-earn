import { useState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

interface SpinWheelProps {
  onSpin: () => Promise<number>;
  spinsRemaining: number;
  isPremium: boolean;
  isSpinning: boolean;
}

const SEGMENTS = [10, 25, 50, 100, 5, 15, 30, 75, 20, 40, 60, 200];
const SEGMENT_COLORS = [
  "hsl(262 83% 58%)",
  "hsl(282 65% 50%)",
  "hsl(242 75% 55%)",
  "hsl(192 70% 45%)",
  "hsl(32 80% 50%)",
  "hsl(262 83% 58%)",
  "hsl(282 65% 50%)",
  "hsl(242 75% 55%)",
  "hsl(192 70% 45%)",
  "hsl(32 80% 50%)",
  "hsl(262 83% 58%)",
  "hsl(282 65% 50%)",
];

export function SpinWheel({ onSpin, spinsRemaining, isPremium, isSpinning }: SpinWheelProps) {
  const [rotation, setRotation] = useState(0);
  const [wonPoints, setWonPoints] = useState<number | null>(null);

  const handleSpin = async () => {
    if (spinsRemaining <= 0 && !isPremium) return;
    
    const points = await onSpin();
    setWonPoints(points);
    
    const winningIndex = SEGMENTS.indexOf(points) !== -1 
      ? SEGMENTS.indexOf(points)
      : Math.floor(Math.random() * SEGMENTS.length);
    
    const extraSpins = 5;
    const degreesPerSegment = 360 / SEGMENTS.length;
    const targetDegree = (360 * extraSpins) - (winningIndex * degreesPerSegment) - (degreesPerSegment / 2);
    
    setRotation(rotation + targetDegree);
    
    setTimeout(() => {
      setWonPoints(null);
    }, 3000);
  };

  return (
    <div className="flex flex-col items-center justify-center gap-8 py-8">
      <div className="relative">
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
          <div className="w-0 h-0 border-l-[20px] border-l-transparent border-r-[20px] border-r-transparent border-t-[30px] border-t-primary drop-shadow-lg" />
        </div>

        <div className="relative w-[min(80vw,400px)] aspect-square">
          <motion.div
            className="w-full h-full rounded-full overflow-hidden relative shadow-2xl"
            style={{ rotate: rotation }}
            transition={{ duration: 4, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <svg viewBox="0 0 200 200" className="w-full h-full">
              {SEGMENTS.map((points, i) => {
                const angle = (360 / SEGMENTS.length) * i;
                const nextAngle = (360 / SEGMENTS.length) * (i + 1);
                const midAngle = (angle + nextAngle) / 2;
                
                const x1 = 100 + 100 * Math.cos((angle * Math.PI) / 180);
                const y1 = 100 + 100 * Math.sin((angle * Math.PI) / 180);
                const x2 = 100 + 100 * Math.cos((nextAngle * Math.PI) / 180);
                const y2 = 100 + 100 * Math.sin((nextAngle * Math.PI) / 180);
                
                const textX = 100 + 65 * Math.cos((midAngle * Math.PI) / 180);
                const textY = 100 + 65 * Math.sin((midAngle * Math.PI) / 180);
                
                return (
                  <g key={i}>
                    <path
                      d={`M 100 100 L ${x1} ${y1} A 100 100 0 0 1 ${x2} ${y2} Z`}
                      fill={SEGMENT_COLORS[i]}
                      stroke="hsl(var(--background))"
                      strokeWidth="2"
                    />
                    <text
                      x={textX}
                      y={textY}
                      fill="white"
                      fontSize="14"
                      fontWeight="800"
                      fontFamily="Poppins"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${midAngle + 90}, ${textX}, ${textY})`}
                    >
                      {points}
                    </text>
                  </g>
                );
              })}
            </svg>
          </motion.div>

          <motion.div 
            className="absolute inset-0 flex items-center justify-center"
            initial={false}
            animate={wonPoints ? { scale: [1, 1.2, 1] } : {}}
            transition={{ duration: 0.5 }}
          >
            <Button
              size="icon"
              className="w-24 h-24 rounded-full shadow-2xl text-xl font-bold"
              onClick={handleSpin}
              disabled={isSpinning || (spinsRemaining <= 0 && !isPremium)}
              data-testid="button-spin"
            >
              {isSpinning ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="w-10 h-10" />
                </motion.div>
              ) : (
                <Sparkles className="w-10 h-10" />
              )}
            </Button>
          </motion.div>
        </div>
      </div>

      {wonPoints && (
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-primary text-primary-foreground px-8 py-4 rounded-full text-3xl font-bold font-heading"
          data-testid="text-points-won"
        >
          +{wonPoints} Points!
        </motion.div>
      )}

      <div className="text-center" data-testid="text-spins-remaining">
        <p className="text-sm text-muted-foreground mb-1">
          {isPremium ? "UNLIMITED SPINS" : "Spins Remaining"}
        </p>
        {!isPremium && (
          <p className="text-5xl font-bold font-heading">
            {spinsRemaining}
          </p>
        )}
        {isPremium && (
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-6 h-6 text-primary animate-pulse-glow" />
            <p className="text-3xl font-bold font-heading text-primary">PREMIUM</p>
            <Sparkles className="w-6 h-6 text-primary animate-pulse-glow" />
          </div>
        )}
      </div>
    </div>
  );
}
