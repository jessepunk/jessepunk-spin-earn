import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Reward } from "@shared/schema";
import { Zap } from "lucide-react";
import { motion } from "framer-motion";

interface RewardsMarketplaceProps {
  userId: string;
  userPoints: number;
}

export function RewardsMarketplace({ userId, userPoints }: RewardsMarketplaceProps) {
  const { toast } = useToast();

  const { data: rewards = [] } = useQuery<Reward[]>({
    queryKey: ["/api/rewards"],
  });

  const redeemMutation = useMutation({
    mutationFn: async (rewardId: string) => {
      return await apiRequest("POST", "/api/redeem", { userId, rewardId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/redemptions"] });
      toast({
        title: "Reward Redeemed!",
        description: "Check your redemptions",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Redemption Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold font-heading">Rewards Marketplace</h2>
        <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full">
          <Zap className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold">{userPoints} points</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {rewards.map((reward) => (
          <motion.div
            key={reward.id}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="hover-elevate transition-all">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="text-4xl">{reward.icon}</div>
                  <Badge variant={userPoints >= reward.pointsCost ? "default" : "secondary"}>
                    {reward.pointsCost} pts
                  </Badge>
                </div>
                <CardTitle className="text-lg mt-2">{reward.name}</CardTitle>
                <CardDescription>{reward.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => redeemMutation.mutate(reward.id)}
                  disabled={userPoints < reward.pointsCost || redeemMutation.isPending}
                  className="w-full rounded-full"
                  data-testid={`button-redeem-${reward.id}`}
                >
                  {redeemMutation.isPending ? "Redeeming..." : "Redeem"}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {rewards.length === 0 && (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No rewards available yet. Check back soon!
          </CardContent>
        </Card>
      )}
    </div>
  );
}
