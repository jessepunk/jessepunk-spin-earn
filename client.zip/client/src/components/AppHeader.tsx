import { Sparkles, Trophy } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import type { User } from "@shared/schema";

interface AppHeaderProps {
  user: User | null;
  farcasterUser?: {
    displayName: string;
    pfpUrl: string;
  } | null;
}

export function AppHeader({ user, farcasterUser }: AppHeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-lg">
      <div className="flex items-center justify-between h-16 px-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-10 h-10 border-2 border-primary" data-testid="img-user-avatar">
            <AvatarImage src={farcasterUser?.pfpUrl || user?.avatarUrl || ""} />
            <AvatarFallback className="bg-primary text-primary-foreground font-bold">
              {farcasterUser?.displayName?.charAt(0) || user?.username?.charAt(0) || "?"}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-semibold leading-none" data-testid="text-username">
              {farcasterUser?.displayName || user?.username || "Guest"}
            </p>
            {user?.isPremium && (
              <Badge variant="default" className="mt-1 text-xs px-2 py-0" data-testid="badge-premium">
                <Sparkles className="w-3 h-3 mr-1" />
                PREMIUM
              </Badge>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-full border border-card-border" data-testid="text-user-points">
            <Trophy className="w-5 h-5 text-primary" />
            <span className="text-2xl font-bold font-heading">
              {user?.points?.toLocaleString() || 0}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
