import { Trophy, Zap, TrendingUp, Target } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import type { User } from "@shared/schema";

interface BalanceStatsProps {
  user: User | null;
  todaySpins: number;
  userRank: number;
}

export function BalanceStats({ user, todaySpins, userRank }: BalanceStatsProps) {
  const stats = [
    {
      icon: Trophy,
      label: "Total Points",
      value: user?.points?.toLocaleString() || "0",
      color: "text-primary",
      testId: "stat-total-points",
    },
    {
      icon: Zap,
      label: "Today's Spins",
      value: todaySpins.toString(),
      color: "text-chart-2",
      testId: "stat-today-spins",
    },
    {
      icon: TrendingUp,
      label: "Your Rank",
      value: userRank > 0 ? `#${userRank}` : "Unranked",
      color: "text-chart-3",
      testId: "stat-user-rank",
    },
    {
      icon: Target,
      label: "Status",
      value: user?.isPremium ? "Premium" : "Free",
      color: user?.isPremium ? "text-primary" : "text-muted-foreground",
      testId: "stat-user-status",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4" data-testid="stats-dashboard">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={stat.label}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-hidden" data-testid={stat.testId}>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center ${stat.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-2xl font-bold font-heading mb-1">
                  {stat.value}
                </p>
                <p className="text-xs text-muted-foreground">
                  {stat.label}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}
