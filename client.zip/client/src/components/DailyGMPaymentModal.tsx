import { useState } from "react";
import { Sunrise, Wallet } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { useAccount, useConnect, useSendTransaction, useWaitForTransactionReceipt } from "wagmi";
import { parseEther } from "viem";
import { injected } from "wagmi/connectors";

interface DailyGMPaymentModalProps {
  isOpen: boolean;
  onPaymentComplete: (txHash: string) => void;
}

const GM_FEE_ETH = "0.000005";
const PAYMENT_ADDRESS = "0x0000000000000000000000000000000000000000";

export function DailyGMPaymentModal({ isOpen, onPaymentComplete }: DailyGMPaymentModalProps) {
  const [isPaying, setIsPaying] = useState(false);
  const { address, isConnected } = useAccount();
  const { connect } = useConnect();
  const { sendTransaction, data: txHash } = useSendTransaction();
  const { isSuccess } = useWaitForTransactionReceipt({
    hash: txHash,
  });

  const handleConnect = () => {
    connect({ connector: injected() });
  };

  const handlePayment = async () => {
    if (!isConnected || !address) {
      handleConnect();
      return;
    }

    setIsPaying(true);
    try {
      await new Promise((resolve, reject) => {
        sendTransaction(
          {
            to: PAYMENT_ADDRESS,
            value: parseEther(GM_FEE_ETH),
          },
          {
            onSuccess: resolve,
            onError: reject,
          }
        );
      });
    } catch (error) {
      console.error("Payment failed:", error);
      setIsPaying(false);
    }
  };

  if (isSuccess && txHash) {
    onPaymentComplete(txHash);
    setIsPaying(false);
  }

  return (
    <Dialog open={isOpen}>
      <DialogContent className="max-w-sm rounded-3xl p-8" data-testid="modal-gm-payment">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <DialogHeader className="text-center">
            <div className="flex justify-center mb-6">
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center">
                  <Sunrise className="w-16 h-16 text-primary-foreground" />
                </div>
              </motion.div>
            </div>

            <DialogTitle className="text-3xl font-bold font-heading">
              Good Morning!
            </DialogTitle>
            <DialogDescription className="text-base mt-2">
              Say GM with a small fee to unlock your daily spins
            </DialogDescription>
          </DialogHeader>

          <div className="mt-8 space-y-6">
            <div className="bg-card border border-card-border rounded-2xl p-6 text-center">
              <p className="text-sm text-muted-foreground mb-2">Daily Fee</p>
              <p className="text-4xl font-bold font-heading" data-testid="text-gm-fee">
                $0.01
              </p>
              <p className="text-xs text-muted-foreground mt-1">({GM_FEE_ETH} ETH)</p>
              <Badge variant="secondary" className="mt-3">
                <span className="text-xs">On Base Network</span>
              </Badge>
            </div>

            <div className="bg-muted/50 rounded-2xl p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">You get:</span>
                <span className="font-semibold">10 Daily Spins</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Network:</span>
                <span className="font-semibold">Base</span>
              </div>
            </div>

            {!isConnected ? (
              <Button
                size="lg"
                className="w-full rounded-full text-lg font-bold py-6"
                onClick={handleConnect}
                data-testid="button-connect-wallet"
              >
                <Wallet className="w-5 h-5 mr-2" />
                Connect Wallet
              </Button>
            ) : (
              <Button
                size="lg"
                className="w-full rounded-full text-lg font-bold py-6"
                onClick={handlePayment}
                disabled={isPaying}
                data-testid="button-pay-gm-fee"
              >
                {isPaying ? "Processing..." : "Pay $0.01"}
              </Button>
            )}
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
