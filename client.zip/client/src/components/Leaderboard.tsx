import { Trophy, Medal, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import type { LeaderboardEntry } from "@shared/schema";

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  currentUserId?: string;
}

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1:
      return <Trophy className="w-6 h-6 text-yellow-500" />;
    case 2:
      return <Medal className="w-6 h-6 text-gray-400" />;
    case 3:
      return <Award className="w-6 h-6 text-amber-700" />;
    default:
      return null;
  }
};

const getRankBadgeVariant = (rank: number) => {
  if (rank <= 3) return "default";
  return "secondary";
};

export function Leaderboard({ entries, currentUserId }: LeaderboardProps) {
  return (
    <Card data-testid="card-leaderboard">
      <CardHeader>
        <CardTitle className="text-2xl font-heading flex items-center gap-2">
          <Trophy className="w-6 h-6 text-primary" />
          Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {entries.length === 0 ? (
          <div className="text-center py-12">
            <Trophy className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No players yet. Be the first!</p>
          </div>
        ) : (
          entries.map((entry, index) => {
            const isCurrentUser = entry.user.id === currentUserId;
            const isTopThree = entry.rank <= 3;

            return (
              <motion.div
                key={entry.user.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`
                  flex items-center gap-4 p-4 rounded-xl transition-colors
                  ${isCurrentUser ? "bg-primary/10 border-2 border-primary" : "bg-card border border-card-border"}
                  ${isTopThree && !isCurrentUser ? "bg-muted/50" : ""}
                `}
                data-testid={`row-leaderboard-${entry.user.id}`}
              >
                <div className="flex items-center justify-center w-12">
                  {getRankIcon(entry.rank) || (
                    <Badge variant={getRankBadgeVariant(entry.rank)} className="w-8 h-8 rounded-full flex items-center justify-center font-bold">
                      {entry.rank}
                    </Badge>
                  )}
                </div>

                <Avatar className={`w-12 h-12 ${isTopThree ? "border-2 border-primary" : ""}`}>
                  <AvatarImage src={entry.user.avatarUrl || ""} />
                  <AvatarFallback className="bg-primary text-primary-foreground font-bold">
                    {entry.user.username?.charAt(0) || "?"}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <p className={`font-semibold truncate ${isCurrentUser ? "text-primary" : ""}`}>
                    {entry.user.username}
                    {isCurrentUser && <span className="ml-2 text-xs">(You)</span>}
                  </p>
                  {entry.user.isPremium && (
                    <Badge variant="outline" className="text-xs px-1.5 py-0 mt-1">
                      PREMIUM
                    </Badge>
                  )}
                </div>

                <div className="text-right">
                  <p className="text-xl font-bold font-heading" data-testid={`text-points-${entry.user.id}`}>
                    {entry.user.points.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">points</p>
                </div>
              </motion.div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
