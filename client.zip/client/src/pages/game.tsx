import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppHeader } from "@/components/AppHeader";
import { SpinWheel } from "@/components/SpinWheel";
import { DailyGMPaymentModal } from "@/components/DailyGMPaymentModal";
import { PremiumUpgradeCard } from "@/components/PremiumUpgradeCard";
import { RewardsMarketplace } from "@/components/RewardsMarketplace";
import { ShareWinModal } from "@/components/ShareWinModal";
import { Leaderboard } from "@/components/Leaderboard";
import { BalanceStats } from "@/components/BalanceStats";
import { useFarcaster } from "@/components/FarcasterProvider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, LeaderboardEntry, SpinResult } from "@shared/schema";
import Confetti from "react-confetti";
import { useWindowSize } from "@/hooks/use-window-size";

export default function Game() {
  const { user: farcasterUser, isReady } = useFarcaster();
  const { toast } = useToast();
  const [showConfetti, setShowConfetti] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const [showGMModal, setShowGMModal] = useState(false);
  const { width, height } = useWindowSize();
  const [shareWinData, setShareWinData] = useState<{ pointsWon: number; totalPoints: number } | null>(null);

  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/user/me", farcasterUser?.fid],
    queryFn: async () => {
      if (!farcasterUser) throw new Error("No Farcaster user");
      const params = new URLSearchParams({
        fid: farcasterUser.fid.toString(),
        username: farcasterUser.username,
        avatarUrl: farcasterUser.pfpUrl,
      });
      const response = await fetch(`/api/user/me?${params}`);
      if (!response.ok) throw new Error("Failed to fetch user");
      return response.json();
    },
    enabled: isReady && !!farcasterUser,
  });

  const { data: leaderboard = [] } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard"],
    enabled: isReady,
  });

  const { data: todaySpins = 0 } = useQuery<number>({
    queryKey: ["/api/user/today-spins", user?.id],
    queryFn: async () => {
      if (!user) return 0;
      const params = new URLSearchParams({ userId: user.id });
      const response = await fetch(`/api/user/today-spins?${params}`);
      if (!response.ok) return 0;
      return response.json();
    },
    enabled: !!user,
  });

  const userRank = leaderboard.findIndex(entry => entry.user.id === user?.id) + 1;

  useEffect(() => {
    if (user) {
      const today = new Date().toDateString();
      const lastPayment = user.lastGmPayment ? new Date(user.lastGmPayment).toDateString() : null;
      
      if (lastPayment !== today && user.dailySpinsRemaining === 0) {
        setShowGMModal(true);
      }
    }
  }, [user]);

  const spinMutation = useMutation({
    mutationFn: async (): Promise<SpinResult> => {
      if (!user) throw new Error("User not found");
      const result = await apiRequest<SpinResult>("POST", "/api/spin", { userId: user.id });
      return result;
    },
    onSuccess: (data: SpinResult) => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/today-spins"] });
      
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 5000);
      setShareWinData({ pointsWon: data.pointsWon, totalPoints: data.newTotalPoints });
      
      toast({
        title: "Spin Complete!",
        description: `You won ${data.pointsWon} points! Total: ${data.newTotalPoints}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Spin Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSpinning(false);
    },
  });

  const gmPaymentMutation = useMutation({
    mutationFn: async (txHash: string) => {
      if (!user) throw new Error("User not found");
      return await apiRequest("POST", "/api/payment/gm", { userId: user.id, txHash });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
      setShowGMModal(false);
      toast({
        title: "GM! ☀️",
        description: "Your daily spins are ready!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const premiumPurchaseMutation = useMutation({
    mutationFn: async (txHash: string) => {
      if (!user) throw new Error("User not found");
      return await apiRequest("POST", "/api/payment/premium", { userId: user.id, txHash });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/me"] });
      toast({
        title: "Welcome to Premium! ⚡",
        description: "You now have unlimited spins!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Purchase Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSpin = async (): Promise<number> => {
    if (!user) return 0;
    
    if (!user.isPremium && user.dailySpinsRemaining <= 0) {
      toast({
        title: "No spins remaining",
        description: "Upgrade to premium for unlimited spins!",
        variant: "destructive",
      });
      return 0;
    }

    setIsSpinning(true);
    try {
      const result = await spinMutation.mutateAsync();
      return result.pointsWon;
    } catch (error) {
      return 0;
    }
  };

  if (!isReady || userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-lg font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  const showPremiumCard = user && !user.isPremium && user.dailySpinsRemaining <= 5;

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(to bottom, #000000 0%, #000000 15%, #FF6B35 15%, #FF6B35 85%, #000000 85%, #000000 100%)' }}>
      {showConfetti && <Confetti width={width} height={height} recycle={false} numberOfPieces={500} />}
      
      <AppHeader user={user || null} farcasterUser={farcasterUser} />

      <main className="pb-12">
        <div className="px-4 space-y-8 text-white">
          <section className="pt-4">
            <h1 className="text-center text-4xl font-bold font-heading mb-2">
              GM, Spin & Win!
            </h1>
            <p className="text-center text-muted-foreground mb-8">
              Spin the wheel daily and climb the leaderboard
            </p>

            <SpinWheel
              onSpin={handleSpin}
              spinsRemaining={user?.dailySpinsRemaining || 0}
              isPremium={user?.isPremium || false}
              isSpinning={isSpinning}
            />
          </section>

          <section>
            <BalanceStats
              user={user || null}
              todaySpins={todaySpins}
              userRank={userRank}
            />
          </section>

          {showPremiumCard && (
            <section>
              <PremiumUpgradeCard
                onPurchaseComplete={(txHash) => premiumPurchaseMutation.mutate(txHash)}
              />
            </section>
          )}

          {user && (
            <section>
              <RewardsMarketplace userId={user.id} userPoints={user.points} />
            </section>
          )}

          <section>
            <Leaderboard entries={leaderboard} currentUserId={user?.id} />
          </section>
        </div>
      </main>

      <DailyGMPaymentModal
        isOpen={showGMModal}
        onPaymentComplete={(txHash) => gmPaymentMutation.mutate(txHash)}
      />

      {shareWinData && (
        <ShareWinModal
          isOpen={!!shareWinData}
          onClose={() => setShareWinData(null)}
          pointsWon={shareWinData.pointsWon}
          totalPoints={shareWinData.totalPoints}
          username={user?.username}
        />
      )}
    </div>
  );
}
