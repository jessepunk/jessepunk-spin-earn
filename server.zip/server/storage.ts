import { 
  type User, 
  type InsertUser, 
  type Spin, 
  type InsertSpin, 
  type Payment, 
  type InsertPayment,
  type LeaderboardEntry,
  type Reward,
  type Redemption,
  users,
  spins,
  payments,
  rewards,
  redemptions,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUserById(id: string): Promise<User | undefined>;
  getUserByFid(fid: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  createSpin(spin: InsertSpin): Promise<Spin>;
  getUserSpinsToday(userId: string): Promise<Spin[]>;
  
  createPayment(payment: InsertPayment): Promise<Payment>;
  getUserPayments(userId: string): Promise<Payment[]>;
  
  getLeaderboard(limit?: number): Promise<LeaderboardEntry[]>;

  getAllRewards(): Promise<Reward[]>;
  redeemReward(userId: string, rewardId: string): Promise<Redemption>;
  getUserRedemptions(userId: string): Promise<(Redemption & { reward: Reward })[]>;
}

export class PostgresStorage implements IStorage {
  async getUserById(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByFid(fid: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.fid, fid));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const result = await db.insert(users).values({
      id,
      fid: insertUser.fid,
      username: insertUser.username,
      avatarUrl: insertUser.avatarUrl ?? null,
      points: 0,
      isPremium: false,
      dailySpinsRemaining: 0,
      lastGmPayment: null,
      premiumPurchasedAt: null,
    }).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async createSpin(insertSpin: InsertSpin): Promise<Spin> {
    const result = await db.insert(spins).values({
      userId: insertSpin.userId,
      pointsWon: insertSpin.pointsWon,
    }).returning();
    return result[0];
  }

  async getUserSpinsToday(userId: string): Promise<Spin[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return db.select().from(spins).where(
      eq(spins.userId, userId)
    ).then(allSpins => {
      return allSpins.filter(spin => {
        const spinDate = new Date(spin.timestamp);
        spinDate.setHours(0, 0, 0, 0);
        return spinDate.getTime() === today.getTime();
      });
    });
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const result = await db.insert(payments).values({
      userId: insertPayment.userId,
      type: insertPayment.type,
      amount: insertPayment.amount,
      txHash: insertPayment.txHash,
    }).returning();
    return result[0];
  }

  async getUserPayments(userId: string): Promise<Payment[]> {
    return db.select().from(payments).where(eq(payments.userId, userId));
  }

  async getLeaderboard(limit: number = 100): Promise<LeaderboardEntry[]> {
    const topUsers = await db.select().from(users)
      .orderBy(desc(users.points))
      .limit(limit);
    
    return topUsers.map((user, index) => ({
      rank: index + 1,
      user,
    }));
  }

  async getAllRewards(): Promise<Reward[]> {
    return db.select().from(rewards);
  }

  async redeemReward(userId: string, rewardId: string): Promise<Redemption> {
    const result = await db.insert(redemptions).values({
      userId,
      rewardId,
    }).returning();
    return result[0];
  }

  async getUserRedemptions(userId: string): Promise<(Redemption & { reward: Reward })[]> {
    const userRedemptions = await db.select().from(redemptions).where(eq(redemptions.userId, userId));
    
    const withRewards = await Promise.all(
      userRedemptions.map(async (r) => {
        const reward = await db.select().from(rewards).where(eq(rewards.id, r.rewardId));
        return {
          ...r,
          reward: reward[0],
        };
      })
    );
    
    return withRewards;
  }
}

export const storage = new PostgresStorage();
