import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPaymentSchema, type SpinResult, type Reward } from "@shared/schema";
import { z } from "zod";

const SPIN_PRIZE_POOL = [10, 25, 50, 100, 5, 15, 30, 75, 20, 40, 60, 200];
const DAILY_FREE_SPINS = 10;

function getRandomPrize(): number {
  return SPIN_PRIZE_POOL[Math.floor(Math.random() * SPIN_PRIZE_POOL.length)];
}

function isSameDay(date1: Date | null, date2: Date): boolean {
  if (!date1) return false;
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate()
  );
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/user/me", async (req: Request, res: Response) => {
    try {
      const fidStr = req.query.fid as string;
      if (!fidStr) {
        return res.status(400).json({ error: "FID required" });
      }

      const validationResult = insertUserSchema.safeParse({
        fid: parseInt(fidStr),
        username: req.query.username as string,
        avatarUrl: req.query.avatarUrl as string || null,
      });

      if (!validationResult.success) {
        return res.status(400).json({ error: "Invalid user data", details: validationResult.error });
      }

      const { fid, username, avatarUrl } = validationResult.data;
      let user = await storage.getUserByFid(fid);
      
      if (!user) {
        user = await storage.createUser({
          fid,
          username: username || `user${fid}`,
          avatarUrl,
        });
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.get("/api/user/today-spins", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: "User ID required" });
      }

      const spins = await storage.getUserSpinsToday(userId);
      res.json(spins.length);
    } catch (error) {
      console.error("Error fetching today's spins:", error);
      res.status(500).json({ error: "Failed to fetch spins" });
    }
  });

  app.get("/api/leaderboard", async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const leaderboard = await storage.getLeaderboard(limit);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  app.post("/api/spin", async (req: Request, res: Response) => {
    try {
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ error: "User ID required" });
      }

      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const today = new Date();
      if (!user.isPremium) {
        if (user.lastGmPayment && !isSameDay(user.lastGmPayment, today)) {
          return res.status(403).json({ error: "Please pay GM fee for today's spins" });
        }

        if (user.dailySpinsRemaining <= 0) {
          return res.status(403).json({ error: "No spins remaining" });
        }
      }

      const pointsWon = getRandomPrize();
      
      await storage.createSpin({
        userId: user.id,
        pointsWon,
      });

      const newPoints = user.points + pointsWon;
      const newSpinsRemaining = user.isPremium 
        ? 999999
        : user.dailySpinsRemaining - 1;

      await storage.updateUser(user.id, {
        points: newPoints,
        dailySpinsRemaining: newSpinsRemaining,
      });

      const result: SpinResult = {
        pointsWon,
        newTotalPoints: newPoints,
        spinsRemaining: newSpinsRemaining,
      };

      res.json(result);
    } catch (error) {
      console.error("Error processing spin:", error);
      res.status(500).json({ error: "Failed to process spin" });
    }
  });

  app.post("/api/payment/gm", async (req: Request, res: Response) => {
    try {
      const validationResult = insertPaymentSchema.extend({
        userId: z.string(),
      }).safeParse({
        userId: req.body.userId,
        type: "gm_fee",
        amount: "0.01",
        txHash: req.body.txHash,
      });

      if (!validationResult.success) {
        return res.status(400).json({ error: "Invalid payment data", details: validationResult.error });
      }

      const { userId, txHash } = validationResult.data;

      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const today = new Date();
      if (user.lastGmPayment && isSameDay(user.lastGmPayment, today)) {
        return res.status(400).json({ error: "GM fee already paid today" });
      }

      const allUsers = await storage.getAllUsers();
      const allPayments = (await Promise.all(
        allUsers.map(u => storage.getUserPayments(u.id))
      )).flat();
      
      if (allPayments.some(p => p.txHash === txHash)) {
        return res.status(400).json({ error: "Transaction hash already used" });
      }

      await storage.createPayment({
        userId: user.id,
        type: "gm_fee",
        amount: "0.000005",
        txHash,
      });

      const updatedUser = await storage.updateUser(user.id, {
        dailySpinsRemaining: DAILY_FREE_SPINS,
        lastGmPayment: today,
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Error processing GM payment:", error);
      res.status(500).json({ error: "Failed to process payment" });
    }
  });

  app.get("/api/rewards", async (req: Request, res: Response) => {
    try {
      const allRewards = await storage.getAllRewards();
      res.json(allRewards);
    } catch (error) {
      console.error("Error fetching rewards:", error);
      res.status(500).json({ error: "Failed to fetch rewards" });
    }
  });

  app.post("/api/redeem", async (req: Request, res: Response) => {
    try {
      const { userId, rewardId } = req.body;
      
      if (!userId || !rewardId) {
        return res.status(400).json({ error: "User ID and reward ID required" });
      }

      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const allRewards = await storage.getAllRewards();
      const reward = allRewards.find(r => r.id === rewardId);
      if (!reward) {
        return res.status(404).json({ error: "Reward not found" });
      }

      if (user.points < reward.pointsCost) {
        return res.status(400).json({ error: "Insufficient points" });
      }

      await storage.redeemReward(userId, rewardId);

      const updatedUser = await storage.updateUser(userId, {
        points: user.points - reward.pointsCost,
      });

      res.json({ user: updatedUser, reward });
    } catch (error) {
      console.error("Error redeeming reward:", error);
      res.status(500).json({ error: "Failed to redeem reward" });
    }
  });

  app.get("/api/user/redemptions", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: "User ID required" });
      }

      const redemptions = await storage.getUserRedemptions(userId);
      res.json(redemptions);
    } catch (error) {
      console.error("Error fetching redemptions:", error);
      res.status(500).json({ error: "Failed to fetch redemptions" });
    }
  });

  app.post("/api/payment/premium", async (req: Request, res: Response) => {
    try {
      const validationResult = insertPaymentSchema.extend({
        userId: z.string(),
      }).safeParse({
        userId: req.body.userId,
        type: "premium",
        amount: "0.0005",
        txHash: req.body.txHash,
      });

      if (!validationResult.success) {
        return res.status(400).json({ error: "Invalid payment data", details: validationResult.error });
      }

      const { userId, txHash } = validationResult.data;

      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      if (user.isPremium) {
        return res.status(400).json({ error: "User already has premium" });
      }

      const allUsers = await storage.getAllUsers();
      const allPayments = (await Promise.all(
        allUsers.map(u => storage.getUserPayments(u.id))
      )).flat();
      
      if (allPayments.some(p => p.txHash === txHash)) {
        return res.status(400).json({ error: "Transaction hash already used" });
      }

      await storage.createPayment({
        userId: user.id,
        type: "premium",
        amount: "0.0005",
        txHash,
      });

      const updatedUser = await storage.updateUser(user.id, {
        isPremium: true,
        premiumPurchasedAt: new Date(),
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Error processing premium purchase:", error);
      res.status(500).json({ error: "Failed to process purchase" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
